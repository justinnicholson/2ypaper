This package of files accompanies

Marc L. Busch and Eric Reinhardt, "Developing Countries and GATT/WTO Dispute Settlement,"
Journal of World Trade 37:4 (2003), 719-735.

Please contact Eric Reinhardt, erein@emory.edu, if you have any questions about these files.

CONTENTS:

Busch-Reinhardt-jwt.dta			Stata Intercooled 7.0 dataset
Busch-Reinhardt-jwt.log			Stata SE 8.0 output file showing paper's results

